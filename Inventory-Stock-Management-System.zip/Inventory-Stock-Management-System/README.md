# Inventory and Stock Management System

A beginner-friendly MySQL DBMS project for managing products, suppliers, purchases, sales, and stock levels.

## Requirements
- MySQL 8.0+ (recommended)
- MySQL Workbench or another MySQL client

## Project structure
```text
Inventory-Stock-Management-System/
├── README.md
├── database/
│   ├── schema.sql
│   ├── sample_data.sql
│   ├── triggers.sql
│   └── demo_transactions.sql
├── queries/
│   ├── basic_queries.sql
│   └── reports.sql
└── screenshots/
    └── .gitkeep
```

## How to run
Run the files in this order in MySQL Workbench:
1. `database/schema.sql`
2. `database/sample_data.sql`
3. `database/triggers.sql`
4. `queries/basic_queries.sql`
5. `queries/reports.sql`
6. `database/demo_transactions.sql` (optional; it changes stock and creates demo purchase/sale records)

Open each SQL file, select all, and execute it. Make sure your MySQL connection is using a user that can create databases, tables, triggers, and procedures if needed.

## Main tables
- `Suppliers`: supplier contact information
- `Products`: product details, prices, current stock, and reorder level
- `Purchases` and `Purchase_Items`: purchase invoices and their line items
- `Sales` and `Sale_Items`: sales invoices and their line items

## DBMS concepts demonstrated
Primary keys, foreign keys, constraints, joins, aggregate functions, views/queries, triggers, and transactions.

## Important notes
- This is an educational project, not a production inventory system.
- The triggers update stock and invoice totals when purchase or sale line items are inserted. They do not automatically handle later edits/deletions of line items.
- For a real system, add user authentication, validation, audit logs, and stronger transaction handling.
- Do not run `demo_transactions.sql` repeatedly unless you want to create additional demo transactions each time.

## GitHub
Upload this folder to a repository named `Inventory-Stock-Management-System`. Add screenshots of successful query outputs to the `screenshots/` folder before submitting, if your instructor requires them.
